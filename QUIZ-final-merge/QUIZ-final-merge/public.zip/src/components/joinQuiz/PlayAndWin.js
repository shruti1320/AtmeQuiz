import React from 'react'

export default function PlayAndWin() {
  return (
    <div>
      <div className='box'>
          <div className='imagediv'>
            
          </div>
      </div>
    </div>
  )
}
