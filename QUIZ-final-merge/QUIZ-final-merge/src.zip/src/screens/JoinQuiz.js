import React from 'react'

export default function JoinQuiz() {
  return (
    <div>
      
    </div>
  )
}
